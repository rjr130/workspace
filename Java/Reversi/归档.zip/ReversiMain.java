import java.io.*;
import java.util.Scanner;
/**
 * This is the Driver class of the Game. Provide with the main method.
 * 
 * @author Junrui Ruan(jruan@wisc.edu) Qianwen Lu (qianwen)
 * 
 */
public class ReversiMain {
	
	//The main method starts the program.
	public static void main (String[] args) throws FileNotFoundException {
		Reversi reversi = new Reversi();
	}
}
