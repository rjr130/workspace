
public class GreedyPlayer {

}
